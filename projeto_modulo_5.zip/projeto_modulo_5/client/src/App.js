import logo from './logo.svg';
import './App.css';
import Axios from "axios";
import Card from "./components/cards/cards";

function App() {
  const [values, setValues] = useState();
  cont [listCard, setListCard] = useState([]);
  console.log(listCard);
  const handleRegisterGame = () => {
    Axios.post("http://localhost:3001/register", {
      name: values.name,
      cost: values.cost,
      category: values.category,
    }).then(() => {
      Axios.post("http://localhost:3001/search", {
        name: values.name,
        cost: values.cost,
        category: values.category,
      }).then((response) => {
        setListCard([
          ...listCard,
          {
            id: response.data[0].id,
            name: values.name,
            cost: values.cost,
            category: values.category,
          };
        ]);
      });
    });
  };
  useEffect(() => {
    axios.get("http://localhost:3001getCards").then(
      (response) =>
      setListCard(response.data);
  });
}, []);

const handleaddValues = (values) => {
  setValues((prevValues) => ({
    ...prevValues,
    [value.target.name]: value.target.value,
  }));
};
  




  return (
    <div className="app-container">




    <button onClick={handleRegisterGame}
    classname="register-button">Cadastrar</button>
    </div>

    {listCard.map((val) => (
      <Card 
      listCard={listCard}
      setListCard={setListCard}
      key={val.id}
      id={val.id}
      nameval.name}

    ))}



export default App;
